import { ChildBarrelComponent } from './child-barrel.component';

export const routes = [
  { path: '', component: ChildBarrelComponent,  pathMatch: 'full' },
];
